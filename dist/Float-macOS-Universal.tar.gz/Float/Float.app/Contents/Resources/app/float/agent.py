"""Float — the turn loop.

One function does the work: ``run`` takes a conversation and yields events for
the browser. Between the model and the operator it handles the tool round trip,
retries transient provider errors, keeps the transcript in the database, and
records what the turn cost.

Events yielded (each is sent to the browser as one SSE frame)::

    {"type": "start",    "conv_id": n, "title": "..."}
    {"type": "text",     "text": "..."}
    {"type": "tool",     "name": "...", "label": "..."}
    {"type": "card",     "card": {...}}          # a file, a task, a run of steps
    {"type": "step",     "text": "..."}          # a pointer action, live
    {"type": "error",    "message": "..."}
    {"type": "done",     "usage": {...}}
"""

from __future__ import annotations

import json
import queue
import threading
import time
from typing import Any, Iterator

from . import attachments as attachment_reader
from . import config, db, providers, tools

MAX_TOOL_ROUNDS = 15      # enough for multi-tool fleet lookup + quote calculation + file creation + task logging
TOOL_LABELS = {
    "create_file": "Building your document",
    "look_up_class": "Checking fleet & booking records",
    "save_task": "Adding to your ops checklist",
    "use_computer": "Using your computer",
    "read_my_day": "Checking today's pickups & returns",
    "calculate_quote": "Calculating exact rental quote",
}


def _history(conv_id: int, limit: int = 30) -> list[dict[str, Any]]:
    """Rebuild the model-facing history from stored messages."""
    rows = db.get_messages(conv_id)[-limit:]
    out: list[dict[str, Any]] = []
    for idx, row in enumerate(rows):
        role = row["role"]
        blocks = row["meta"].get("blocks")
        if role == "tool":
            if blocks and out and out[-1]["role"] == "assistant" and isinstance(out[-1]["content"], list):
                if any(isinstance(b, dict) and b.get("type") == "tool_use" for b in out[-1]["content"]):
                    out.append({"role": "user", "content": blocks})
            continue
        if role not in {"user", "assistant"}:
            continue
        if role == "assistant" and isinstance(blocks, list):
            has_tool_use = any(isinstance(b, dict) and b.get("type") == "tool_use" for b in blocks)
            next_is_tool = (idx + 1 < len(rows) and rows[idx + 1]["role"] == "tool"
                            and bool(rows[idx + 1]["meta"].get("blocks")))
            if has_tool_use and not next_is_tool:
                text_only = [b for b in blocks if isinstance(b, dict) and b.get("type") == "text" and b.get("text")]
                if text_only:
                    out.append({"role": "assistant", "content": text_only})
                elif (row["content"] or "").strip():
                    out.append({"role": "assistant", "content": row["content"]})
                continue
        content = blocks if blocks else row["content"]
        if role == "assistant" and not content:
            continue
        out.append({"role": role, "content": content})
    while out and out[0]["role"] != "user":
        out.pop(0)
    return out


def _sees_images(provider: str) -> bool:
    """Does this provider get the screenshot a pointer run produces?"""
    mode = config.settings.computer_vision
    if mode == "off" or provider == "local":
        return False
    return mode == "on" or provider in {"anthropic", "openai", "google"}


def _drop_old_screens(history: list[dict[str, Any]]) -> None:
    """Only the newest screenshot is worth its tokens: an old one shows a screen
    that no longer exists. Replace earlier ones with their text."""
    for message in history:
        content = message.get("content")
        if not isinstance(content, list):
            continue
        for block in content:
            if block.get("type") == "tool_result" and isinstance(block.get("content"), list):
                block["content"] = "\n".join(
                    b.get("text", "") for b in block["content"] if isinstance(b, dict) and b.get("type") == "text")


def title_for(text: str) -> str:
    clean = " ".join((text or "").strip().split())
    if len(clean) <= 52:
        return clean or "New conversation"
    cut = clean[:52].rsplit(" ", 1)[0]
    return (cut or clean[:52]) + "…"


def pick_model(user: dict[str, Any], requested: str = "") -> tuple[str, str, str]:
    """Return (provider, model, key). Falls back to whatever the agency has set up."""
    allowed = db.allowed_providers()
    provider, _, model = (requested or "").partition(":")

    if provider == "local" and config.rt_enabled():
        return "local", model or config.RT_MODEL, ""

    if provider in allowed:
        key = db.get_key(provider, int(user["id"]))
        if key:
            spec = config.PROVIDERS[provider]
            return provider, model or spec.default_model, key

    for candidate in allowed:
        key = db.get_key(candidate, int(user["id"]))
        if key:
            return candidate, config.PROVIDERS[candidate].default_model, key

    if config.rt_enabled():
        return "local", config.RT_MODEL, ""

    return (provider or "anthropic"), model, ""


def run(user: dict[str, Any], conv_id: int, message: str, model_choice: str = "",
        allow_computer: bool = True, attachments: list[dict[str, Any]] | None = None
        ) -> Iterator[dict[str, Any]]:
    """Take one turn. Yields events; never raises for an expected failure."""
    started = time.time()
    provider, model, key = pick_model(user, model_choice)

    conversation = db.get_conversation(conv_id, int(user["id"]))
    if conversation is None:
        yield {"type": "error", "message": "That conversation is gone. Start a new one."}
        return

    user_blocks: list[dict[str, Any]] = []
    if message.strip():
        user_blocks.append({"type": "text", "text": message})
    for attachment in attachments or []:
        if not isinstance(attachment, dict):
            continue
        if attachment.get("kind") == "image":
            if provider != "local":
                user_blocks.append({
                    "type": "image",
                    "source": {"type": "base64",
                               "media_type": attachment.get("media_type") or attachment.get("mime") or "image/png",
                               "data": attachment.get("data", "")},
                })
            continue
        try:
            body_text = attachment_reader.to_text(attachment)
        except attachment_reader.AttachmentError as exc:
            yield {"type": "error", "message": str(exc)}
            return
        user_blocks.append({
            "type": "text",
            "text": f"\n\n--- {attachment.get('name', 'attached file')} ---\n{body_text}",
        })

    keep_user_blocks = len(user_blocks) > 1 or (
        len(user_blocks) == 1 and (user_blocks[0].get("type") != "text" or user_blocks[0].get("text") != message)
    )
    db.add_message(conv_id, "user", message, {"blocks": user_blocks if keep_user_blocks else None})

    if conversation["title"] in {"New conversation", ""} and message.strip():
        new_title = title_for(message)
        db.rename_conversation(conv_id, int(user["id"]), new_title)
        yield {"type": "start", "conv_id": conv_id, "title": new_title}
    else:
        yield {"type": "start", "conv_id": conv_id, "title": conversation["title"]}

    history = _history(conv_id)
    system = tools.system_prompt(user)
    can_use_computer = bool(allow_computer and config.settings.computer_control)
    schemas = tools.tools_for(user, can_use_computer)

    total_in = total_out = 0
    reply_text: list[str] = []

    for round_index in range(MAX_TOOL_ROUNDS):
        assistant_blocks: list[dict[str, Any]] = []
        pending: list[dict[str, Any]] = []
        buffer: list[str] = []
        stop = "end_turn"

        try:
            for event in _with_retry(provider, key, model, system, history, schemas):
                kind = event["type"]
                if kind == "text":
                    buffer.append(event["text"])
                    reply_text.append(event["text"])
                    yield {"type": "text", "text": event["text"]}
                elif kind == "tool":
                    if buffer:
                        assistant_blocks.append({"type": "text", "text": "".join(buffer)})
                        buffer.clear()
                    assistant_blocks.append({
                        "type": "tool_use", "id": event["id"],
                        "name": event["name"], "input": event["input"],
                    })
                    pending.append(event)
                    label = TOOL_LABELS.get(event["name"]) or tools.tool_label(event["name"])
                    yield {"type": "tool", "name": event["name"], "label": label}
                elif kind == "usage":
                    total_in += event.get("tokens_in", 0)
                    total_out += event.get("tokens_out", 0)
                elif kind == "done":
                    stop = event.get("stop", "end_turn")
        except providers.ProviderError as exc:
            db.record_usage(int(user["id"]), provider, model, total_in, total_out, 0,
                            int((time.time() - started) * 1000), ok=False)
            db.audit("chat.error", user_id=int(user["id"]), actor=user.get("name", ""),
                     detail=exc.message[:300], level="error")
            yield {"type": "error", "message": exc.message}
            return

        if buffer:
            assistant_blocks.append({"type": "text", "text": "".join(buffer)})

        if not pending or stop != "tool_use":
            db.add_message(conv_id, "assistant", "".join(reply_text),
                           {"blocks": assistant_blocks if (len(assistant_blocks) > 1 or round_index > 0) else None,
                            "provider": provider, "model": model})
            break

        history.append({"role": "assistant", "content": assistant_blocks})
        db.add_message(conv_id, "assistant", "", {"blocks": assistant_blocks,
                                                  "provider": provider, "model": model})

        results: list[dict[str, Any]] = []
        shown: list[dict[str, Any]] = []
        step_queue: queue.Queue = queue.Queue()

        for call in pending:
            def emit(payload: dict[str, Any]) -> None:
                step_queue.put(payload)

            outcome = _call_tool(call, user, conv_id, emit, step_queue, allow_computer=can_use_computer)
            for item in _drain(step_queue):
                yield item
            if outcome.get("card"):
                yield {"type": "card", "card": outcome["card"]}
            text = outcome["text"][:20_000]
            image = outcome.get("image")
            results.append({
                "type": "tool_result",
                "tool_use_id": call["id"],
                "name": call["name"],
                "content": text,
            })
            if image and _sees_images(provider):           # the model's eyes
                shown.append({**results[-1], "content": [
                    {"type": "text", "text": text},
                    {"type": "image", "source": {"type": "base64", "media_type": image["media_type"],
                                                 "data": image["data"]}}]})
            else:
                shown.append(results[-1])

        _drop_old_screens(history)
        history.append({"role": "user", "content": shown})
        db.add_message(conv_id, "tool", json.dumps([r["name"] for r in results]),
                       {"blocks": results})                 # stored as text; screenshots are never saved
    else:
        yield {"type": "error",
               "message": "That took more tool steps than Float allows in one go. "
                          "Ask for a smaller piece of it."}

    paise = providers.estimate_paise(provider, model, total_in, total_out)
    db.record_usage(int(user["id"]), provider, model, total_in, total_out, paise,
                    int((time.time() - started) * 1000), ok=True)

    yield {
        "type": "done",
        "usage": {
            "tokens_in": total_in,
            "tokens_out": total_out,
            "paise": round(paise, 2),
            "seconds": round(time.time() - started, 1),
            "provider": provider,
            "model": model,
        },
    }


def _drain(step_queue: "queue.Queue") -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    while True:
        try:
            out.append(step_queue.get_nowait())
        except queue.Empty:
            return out


def _call_tool(call: dict[str, Any], user: dict[str, Any], conv_id: int,
               emit: Any, step_queue: "queue.Queue", allow_computer: bool = True) -> dict[str, Any]:
    """Run a tool on a worker thread so a long pointer run still streams steps."""
    result: dict[str, Any] = {}

    def work() -> None:
        result.update(tools.execute(call["name"], call.get("input", {}), user, conv_id, emit,
                                    allow_computer=allow_computer))

    thread = threading.Thread(target=work, daemon=True, name=f"float-tool-{call['name']}")
    thread.start()
    thread.join(timeout=600)
    if thread.is_alive():
        return {"text": "That tool ran too long and was abandoned.", "card": None}
    return result or {"text": "The tool returned nothing.", "card": None}


def _with_retry(provider: str, key: str, model: str, system: str,
                history: list[dict[str, Any]], schemas: list[dict[str, Any]]
                ) -> Iterator[dict[str, Any]]:
    """One retry, and only for the failures where retrying is the right answer."""
    attempt = 0
    while True:
        try:
            yield from providers.stream(provider, key, model, system, history, schemas)
            return
        except providers.ProviderError as exc:
            if not exc.retryable or attempt >= 1:
                raise
            attempt += 1
            time.sleep(1.5)
