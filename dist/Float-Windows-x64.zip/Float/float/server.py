"""Float — the server.

A threaded ``http.server`` bound to loopback. No framework, for the same reason
the rest of Float has no dependencies: the machine this runs on is a rental counter
laptop, and the install has to work on the first try, offline, behind a proxy
that blocks half of PyPI.

What guards it:

* By default it binds to 127.0.0.1:8766 (or 0.0.0.0:8766 in --lan Agency Server mode with fixed-desk IP session binding).
* The ``Host`` header is checked, which closes the DNS-rebinding version of the
  same problem — a page on the internet resolving a name to 127.0.0.1 and
  talking to this port from the operator's own browser.
* Authentication is a bearer token in a header, never a cookie, so there is no
  CSRF surface to defend: a cross-origin page cannot make the browser attach it.
* The token is kept in ``sessionStorage``, which the browser discards when the
  tab closes, and the session it names is bound to this process's boot nonce, so
  closing Float invalidates it server-side too.
"""

from __future__ import annotations

import concurrent.futures
import hashlib
import ipaddress
import json
import math
import mimetypes
import os
import posixpath
import re
import shlex
import socket
import ssl
import sys
import threading
import time
import traceback
import urllib.parse
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable

from . import agent, artifacts, computer, config, db, google, greeting, maintenance, mcp, providers, rental_ops, security, stats, tools, transport

Handler = Callable[["Route"], Any]
_routes: list[tuple[str, re.Pattern[str], Handler, str]] = []
_exact_routes: dict[tuple[str, str], tuple[re.Pattern[str], Handler, str]] = {}
_LOCAL_HOSTNAME = socket.gethostname().lower()
_STATIC_CACHE: dict[Path, tuple[int, int, bytes, str, str]] = {}
_STATIC_LOCK = threading.Lock()


class HttpError(Exception):
    def __init__(self, status: int, message: str, **extra: Any) -> None:
        super().__init__(message)
        self.status = status
        self.message = message
        self.extra = extra          # e.g. must_change=True, passed through to the client


# Routes a user on a temporary password may still call: enough to load the app
# shell, choose a real password, or sign out. Everything else waits.
_MUST_CHANGE_ALLOWED = {
    ("GET", "/api/bootstrap"),
    ("GET", "/api/me"),
    ("POST", "/api/me/password"),
    ("POST", "/api/auth/signout"),
}


def _log_unexpected() -> str:
    """Record the current exception where a person can find it, and return a short
    reference to show the user. Never raises: when Float runs windowless there is
    no stderr, and a logging failure must not turn one error into a dropped
    connection."""
    ref = security.new_token(4)
    text = traceback.format_exc()
    try:
        if sys.stderr:
            print(f"[{ref}] {text}", file=sys.stderr)
    except Exception:
        pass
    try:
        config.DATA_DIR.mkdir(parents=True, exist_ok=True)
        log = config.DATA_DIR / "float_errors.log"
        if log.exists() and log.stat().st_size > 512_000:      # keep it from growing forever
            log.replace(log.with_suffix(".log.old"))
        with log.open("a", encoding="utf-8") as handle:
            handle.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] ref {ref}\n{text}")
    except Exception:
        pass
    return ref


class Route:
    """Everything a handler needs: the request, the user, and the parsed body."""

    def __init__(self, request: "FloatHandler", params: dict[str, str]) -> None:
        self.request = request
        self.params = params
        self.user: dict[str, Any] | None = None
        self.token: str = ""

    @property
    def body(self) -> dict[str, Any]:
        return self.request.json_body()

    @property
    def query(self) -> dict[str, str]:
        return self.request.query

    @property
    def ip(self) -> str:
        return self.request.client_address[0]

    @property
    def local(self) -> bool:
        """True only when the request comes from the Float computer itself.

        Anything that touches the machine Float runs on (moving its mouse, saving
        to its Desktop) is allowed only for such requests, so an operator on another
        PC can never act on - or see - what happens on the server. A request that
        carries proxy headers is never treated as local."""
        headers = self.request.headers
        if any(headers.get(k) for k in ("X-Forwarded-For", "Forwarded", "X-Real-IP")):
            return False
        peer = self.ip
        if peer in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
            return True
        try:   # opened through the machine's own network address
            return peer == self.request.connection.getsockname()[0]
        except OSError:
            return False

    def require_user(self) -> dict[str, Any]:
        if self.user is None:
            raise HttpError(401, "Sign in to continue.")
        return self.user

    def require_admin(self) -> dict[str, Any]:
        user = self.require_user()
        if user["role"] != "admin" and rental_ops.effective_role(user) not in {"owner", "manager"}:
            raise HttpError(403, "That area is for admins.")
        return user

    def require_perm(self, perm: str) -> dict[str, Any]:
        user = self.require_user()
        if not rental_ops.has_permission(user, perm):
            raise HttpError(403, f"Your role ({rental_ops.effective_role(user)}) does not have permission for '{perm}'.")
        return user


# Endpoints that carry passwords, PINs or API keys. Their bodies must arrive
# AES-256-GCM encrypted (see transport.py); plain bodies are refused.
_SEALED = re.compile(r"^/api/(auth/signin|auth/signup|me/password|me/pin|keys|unlock|admin/users(/\d+)?)$")


def route(method: str, pattern: str, auth: str = "user") -> Callable[[Handler], Handler]:
    """auth: 'none' | 'user' | 'admin'."""
    def _param(m: "re.Match[str]") -> str:
        name = m.group(1)   # numeric ids must be digits, so "abc" is a 404, not a crash
        digits = name.endswith("_id") and name != "entry_id"
        sub = r"\d{1,18}" if digits else "[^/]+"
        return "(?P<" + name + ">" + sub + ")"

    regex = re.compile("^" + re.sub(r"\{(\w+)\}", _param, pattern) + "$")

    def decorate(handler: Handler) -> Handler:
        _routes.append((method, regex, handler, auth))
        if "{" not in pattern:
            _exact_routes[(method, pattern)] = (regex, handler, auth)
        return handler

    return decorate


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
@route("GET", "/api/crypto/key", auth="none")
def crypto_key(ctx: Route) -> dict[str, Any]:
    return transport.public_info()


@route("POST", "/api/auth/state", auth="none")
def auth_state(ctx: Route) -> dict[str, Any]:
    return {
        "setup_needed": db.count_users() == 0,
        "local": ctx.local,
        "self_signup": db.org_get("self_signup", "0") == "1",
        "school": db.org_get("school_name", config.settings.school_name),
        "app": {"name": config.APP_NAME, "version": config.VERSION, "tagline": config.APP_TAGLINE},
    }


@route("POST", "/api/auth/signup", auth="none")
def auth_signup(ctx: Route) -> dict[str, Any]:
    allowed, wait = security.signup_limiter.check(f"signup:{ctx.ip}")
    if not allowed:
        raise HttpError(429, f"Too many sign-up attempts. Try again in {int(wait)} seconds.")
    body = ctx.body
    email = str(body.get("email", "")).strip().lower()
    name = str(body.get("name", "")).strip() or email.split("@")[0]
    password = str(body.get("password", ""))

    first_user = db.count_users() == 0
    if first_user and config.settings.lan and not ctx.local:
        raise HttpError(403, "The first account must be created on the Float computer itself, "
                             "so nobody on the network can claim the agency.")
    if not first_user and db.org_get("self_signup", "0") != "1":
        raise HttpError(403, "Your agency creates accounts from the admin panel. Ask your admin to add you.")
    if "@" not in email or len(email) < 6:
        raise HttpError(400, "That email address does not look right.")
    if db.get_user_by_email(email):
        raise HttpError(409, "There is already an account with that email. Sign in instead.")
    problems = security.password_problems(password)
    if problems:
        raise HttpError(400, " ".join(problems))

    user = db.create_user(email, name, password, role="admin" if first_user else "teacher",
                          school=str(body.get("school", "")).strip())
    if first_user and body.get("school"):
        db.org_set("school_name", str(body["school"]).strip())
    db.audit("auth.signup", user_id=int(user["id"]), actor=user["name"],
             detail="first account, made admin" if first_user else "self sign-up", ip=ctx.ip)
    token = db.create_session(int(user["id"]), ctx.ip, ctx.request.headers.get("User-Agent", ""))
    db.touch_user(int(user["id"]), count_sign_in=True)
    return {"token": token, "user": _public_user(user)}


@route("POST", "/api/auth/signin", auth="none")
def auth_signin(ctx: Route) -> dict[str, Any]:
    body = ctx.body
    email = str(body.get("email", "")).strip().lower()
    password = str(body.get("password", ""))
    pin = str(body.get("pin", ""))

    allowed, wait = security.sign_in_limiter.check(f"{ctx.ip}:{email}")
    if not allowed:
        raise HttpError(429, f"Too many attempts. Try again in {int(wait)} seconds.")

    user = db.get_user_by_email(email)
    failed = user is None or not user["active"]
    if not failed:
        if pin and user["pin_hash"]:
            failed = not security.verify_password(pin, user["pin_hash"])
        elif password and user["password_hash"]:
            failed = not security.verify_password(password, user["password_hash"])
        else:
            failed = True

    if failed:
        db.audit("auth.fail", user_id=user["id"] if user else None, actor=email,
                 detail="wrong credentials" if user else "unknown account", ip=ctx.ip, level="warn")
        raise HttpError(401, "That email and password don't match. Check both, or ask your admin to reset it.")

    security.sign_in_limiter.reset(f"{ctx.ip}:{email}")
    token = db.create_session(int(user["id"]), ctx.ip, ctx.request.headers.get("User-Agent", ""))
    db.touch_user(int(user["id"]), count_sign_in=True)
    db.audit("auth.signin", user_id=int(user["id"]), actor=user["name"],
             detail="pin" if pin else "password", ip=ctx.ip)
    return {"token": token, "user": _public_user(user), "must_change": bool(user["must_change"])}


@route("POST", "/api/auth/signout")
def auth_signout(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    db.end_session(ctx.token)
    google.forget(int(user["id"]))
    db.audit("auth.signout", user_id=int(user["id"]), actor=user["name"], ip=ctx.ip)
    return {"ok": True}


@route("GET", "/api/auth/google/start", auth="none")
def google_start(ctx: Route) -> dict[str, Any]:
    want_drive = ctx.query.get("drive") == "1"
    if not want_drive:
        raise HttpError(400, "Google sign-in has been removed. Sign in with your Float email and password.")
    if config.settings.lan:
        raise HttpError(400, "Google Drive is switched off on an agency server, so one operator's files never touch another's account.")
    if not google.configured():
        raise HttpError(400, "Google Drive is not set up for this installation.")
    user_id = None
    if want_drive:
        user = ctx.require_user()
        user_id = int(user["id"])
    _scheme = "https" if config.tls_files() else "http"
    _host = "127.0.0.1" if config.settings.host in ("0.0.0.0", "::") else config.settings.host
    redirect = f"{_scheme}://{_host}:{ctx.request.server.server_port}/auth/google/callback"
    return {"url": google.start(redirect, want_drive, user_id)}


@route("POST", "/api/auth/google/setup", auth="none")
def google_setup(ctx: Route) -> dict[str, Any]:
    """Save the agency's Google OAuth client. First-run setup or an admin only."""
    if db.count_users() > 0 and (ctx.user is None or ctx.user["role"] != "admin"):
        raise HttpError(403, "Only an admin can change the Google sign-in settings.")
    client_id = str(ctx.body.get("client_id", "")).strip()
    client_secret = str(ctx.body.get("client_secret", "")).strip()
    if not client_id or not client_secret or len(client_id) > 300 or len(client_secret) > 300:
        raise HttpError(400, "Paste both the client ID and the client secret.")
    config.save_google(client_id, client_secret)
    db.audit("google.setup", detail="client saved", ip=ctx.ip, level="warn")
    return {"ok": True}


@route("GET", "/auth/google/callback", auth="none")
def google_callback(ctx: Route) -> Any:
    error = ctx.query.get("error")
    if error:
        return _close_window(f"Google sign-in was cancelled ({error}).", ok=False)
    try:
        result = google.finish(ctx.query.get("state", ""), ctx.query.get("code", ""))
    except google.GoogleError as exc:
        return _close_window(str(exc), ok=False)

    # Connecting Drive to an account that is already signed in.
    if result.get("user_id"):
        google.remember(int(result["user_id"]), result)
        db.audit("google.drive", user_id=int(result["user_id"]), detail="Drive connected", ip=ctx.ip)
        return _close_window("Google Drive connected. You can close this tab.", ok=True)

    return _close_window("Google sign-in has been removed. Sign in with your Float email and password.", ok=False)


def _close_window(message: str, ok: bool, token: str = "") -> tuple[str, str]:
    payload = json.dumps({"ok": ok, "message": message, "token": token})
    page = f"""<!doctype html><meta charset="utf-8"><title>Float</title>
<style>body{{font:16px/1.6 system-ui,sans-serif;background:#1E3A32;color:#FBF9F4;
display:grid;place-items:center;height:100vh;margin:0;text-align:center;padding:2rem}}
p{{max-width:28rem}} strong{{font-family:"Times New Roman",serif;font-size:1.6rem;display:block;margin-bottom:.5rem}}</style>
<p><strong>{'Done' if ok else 'Not signed in'}</strong>{message}</p>
<script>
  try {{ window.opener && window.opener.postMessage({payload}, "*"); }} catch (e) {{}}
  setTimeout(() => window.close(), {1200 if ok else 4000});
</script>"""
    return ("html", page)


# ---------------------------------------------------------------------------
# Me
# ---------------------------------------------------------------------------
def _public_user(user: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": user["id"],
        "email": user["email"],
        "name": user["name"],
        "role": user["role"],
        "ops_role": rental_ops.effective_role(user),
        "branch_id": int(user.get("branch_id") or 1),
        "school": user["school"],
        "board": user["board"],
        "subjects": _as_list(user["subjects"]),
        "grades": _as_list(user["grades"]),
        "language": user["language"],
        "assist_level": user["assist_level"],
        "accent": user["accent"],
        "appearance": user["appearance"],
        "has_pin": bool(user["pin_hash"]),
        "sign_ins": user["sign_ins"],
        "must_change": bool(user["must_change"]),
    }


def _as_list(value: Any) -> list[str]:
    try:
        parsed = json.loads(value or "[]")
        return parsed if isinstance(parsed, list) else []
    except (ValueError, TypeError):
        return []


@route("GET", "/api/me")
def me(ctx: Route) -> dict[str, Any]:
    return {"user": _public_user(ctx.require_user())}


@route("POST", "/api/me")
def me_update(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    body = ctx.body
    updates: dict[str, Any] = {}
    for key in ("name", "school", "board", "language", "accent", "appearance"):
        if key in body:
            updates[key] = str(body[key])[:120]
    if "assist_level" in body and body["assist_level"] in config.ASSIST_LEVELS:
        updates["assist_level"] = body["assist_level"]
    for key in ("subjects", "grades"):
        if key in body and isinstance(body[key], list):
            updates[key] = json.dumps([str(v)[:60] for v in body[key]][:30])
    db.update_user(int(user["id"]), **updates)
    return {"user": _public_user(db.get_user(int(user["id"])) or user)}


@route("POST", "/api/me/password")
def me_password(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    body = ctx.body
    current = str(body.get("current", ""))
    new = str(body.get("new") or body.get("next") or "")
    if user["password_hash"] and not security.verify_password(current, user["password_hash"]):
        raise HttpError(403, "That current password is not right.")
    problems = security.password_problems(new)
    if problems:
        raise HttpError(400, " ".join(problems))
    db.set_password(int(user["id"]), new)
    db.audit("auth.password", user_id=int(user["id"]), actor=user["name"], ip=ctx.ip)
    return {"ok": True}


@route("POST", "/api/me/pin")
def me_pin(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    body = ctx.body
    pin = str(body.get("pin", ""))
    if pin:
        if not security.verify_password(str(body.get("password", "")), user["password_hash"] or ""):
            raise HttpError(403, "Enter your password to set a quick PIN.")
        problems = security.pin_problems(pin)
        if problems:
            raise HttpError(400, " ".join(problems))
    db.set_pin(int(user["id"]), pin)
    db.audit("auth.pin", user_id=int(user["id"]), actor=user["name"],
             detail="set" if pin else "removed", ip=ctx.ip)
    return {"ok": True, "has_pin": bool(pin)}


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------
@route("GET", "/api/bootstrap")
def bootstrap(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    user_id = int(user["id"])
    can_drive = google.has_drive(user_id) and not config.settings.lan
    control_ok, control_why = computer.available()
    if not ctx.local:
        control_ok = False
        control_why = ("Float can only use a computer when you are sitting at the Float "
                       "computer itself. On this PC it works through your browser, so it "
                       "cannot move your mouse. Everything else works as normal.")

    models: list[dict[str, Any]] = []
    for provider_id in db.allowed_providers():
        spec = config.PROVIDERS[provider_id]
        has_key = bool(db.get_key(provider_id, user_id))
        for model in spec.models:
            models.append({
                "id": f"{provider_id}:{model.id}",
                "provider": provider_id,
                "provider_label": spec.label,
                "label": model.label,
                "ready": has_key,
            })
    if config.rt_enabled():
        from . import _runtime_ext

        for name in _runtime_ext.models() or [config.RT_MODEL]:
            models.append({"id": f"local:{name}", "provider": "local",
                           "provider_label": "On this machine", "label": name, "ready": True})

    return {
        "user": _public_user(user),
        "greeting": greeting.build(user),
        "reflection": greeting.week_reflection(user_id),
        "conversations": db.list_conversations(user_id),
        "toolkit": tools.TOOLKIT,
        "toolkit_groups": tools.TOOLKIT_GROUPS,
        "classes": db.list_classes(user_id),
        "tasks": db.list_tasks(user_id),
        "artifacts": db.list_artifacts(user_id, 24),
        "notices": db.active_notices(),
        "models": models,
        "keys": db.key_status(user_id),
        "providers": [
            {"id": p, "label": config.PROVIDERS[p].label, "help": config.PROVIDERS[p].key_help,
             "console": config.PROVIDERS[p].console_url}
            for p in db.allowed_providers()
        ],
        "options": {
            "boards": list(config.BOARDS),
            "subjects": list(config.SUBJECTS),
            "grades": list(config.GRADES),
            "languages": config.LANGUAGES,
            "assist": config.ASSIST_LEVELS,
        },
        "capabilities": {
            "drive": can_drive,
            "google": google.configured() and not config.settings.lan,
            "local": ctx.local,
            "lan": config.settings.lan,
            "desk_ip": ctx.ip,
            "secure": bool(config.tls_files()),
            "computer": control_ok,
            "computer_why": control_why,
            "screen": computer.screenshot_size(),
            "teacher_own_keys": db.org_get("teacher_own_keys", "1") == "1",
            "mcp": True,
        },
        "usage": {**db.usage_for_user(user_id), "month_paise": db.month_paise(user_id),
                  "cap_paise": db.cap_for(user_id)[0]},
        "own_work": db.own_work_summary(user_id),
        "branches": rental_ops.list_branches(),
        "roles": list(rental_ops.ROLES),
    }


# ---------------------------------------------------------------------------
# Chat
# ---------------------------------------------------------------------------
@route("POST", "/api/chat")
def chat(ctx: Route) -> Any:
    user = ctx.require_user()
    body = ctx.body
    allowed, wait = security.chat_limiter.check(str(user["id"]))
    if not allowed:
        raise HttpError(429, f"Slow down a moment — try again in {int(wait)}s.")

    cap, _custom = db.cap_for(int(user["id"]))
    if cap > 0 and not db.has_own_key(int(user["id"])) and db.month_paise(int(user["id"])) >= cap:
        raise HttpError(429, "You've used your share of the agency's AI budget for this month. "
                             "It resets on the 1st, or your admin can adjust it. "
                             "Your fleet groups, logs and saved files all still work.")

    message = str(body.get("message", ""))
    conv_id = body.get("conv_id")
    if not conv_id:
        conv_id = db.new_conversation(int(user["id"]), agent.title_for(message),
                                      str(body.get("tool", "chat")))
    conv_id = int(conv_id)

    stream = agent.run(
        user,
        conv_id,
        message,
        model_choice=str(body.get("model", "")),
        allow_computer=bool(body.get("allow_computer", True)) and ctx.local,
        attachments=body.get("attachments") or [],
    )
    return ("sse", stream)


@route("GET", "/api/conversations")
def conversations(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    return {"conversations": db.list_conversations(int(user["id"]))}


@route("GET", "/api/conversations/{conv_id}")
def conversation_detail(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    conv_id = int(ctx.params["conv_id"])
    conversation = db.get_conversation(conv_id, int(user["id"]))
    if conversation is None:
        raise HttpError(404, "No such conversation.")
    messages = [
        {"role": m["role"], "content": m["content"], "created_at": m["created_at"],
         "meta": {k: v for k, v in m["meta"].items() if k != "blocks"}}
        for m in db.get_messages(conv_id)
        if m["role"] in {"user", "assistant"} and m["content"].strip()
    ]
    return {"conversation": conversation, "messages": messages,
            "artifacts": db.list_artifacts(int(user["id"]), 200, conv_id=conv_id)}


@route("POST", "/api/conversations/{conv_id}")
def conversation_update(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    conv_id = int(ctx.params["conv_id"])
    body = ctx.body
    if "title" in body:
        db.rename_conversation(conv_id, int(user["id"]), str(body["title"]))
    for flag in ("pinned", "archived"):
        if flag in body:
            db.set_conversation_flag(conv_id, int(user["id"]), flag, 1 if body[flag] else 0)
    return {"ok": True}


@route("DELETE", "/api/conversations/{conv_id}")
def conversation_delete(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    if db.get_conversation(int(ctx.params["conv_id"]), int(user["id"])) is None:
        raise HttpError(404, "No such conversation.")
    db.delete_conversation(int(ctx.params["conv_id"]), int(user["id"]))
    return {"ok": True}


@route("POST", "/api/toolkit/{entry_id}")
def toolkit_run(ctx: Route) -> dict[str, Any]:
    """Turn a filled-in toolkit form into a prompt and a fresh conversation."""
    user = ctx.require_user()
    entry = tools.toolkit_entry(ctx.params["entry_id"])
    if entry is None:
        raise HttpError(404, "No such tool.")
    values = ctx.body.get("values")
    if not isinstance(values, dict):
        values = {}
    try:
        prompt = tools.fill_prompt(entry, values)
    except stats.MarksError as exc:
        raise HttpError(400, f"I couldn't read those marks. {exc}") from None
    title = f"{entry['name']}" + (
        f" — {values.get('topic') or values.get('klass', '')}" if values else ""
    )
    conv_id = db.new_conversation(int(user["id"]), title.strip(" —")[:120], entry["id"])
    return {"conv_id": conv_id, "prompt": prompt, "title": title}


# ---------------------------------------------------------------------------
# Files
# ---------------------------------------------------------------------------
@route("GET", "/api/artifacts")
def artifacts_list(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    return {"artifacts": db.list_artifacts(int(user["id"]))}


@route("GET", "/api/artifacts/{artifact_id}/download")
def artifact_download(ctx: Route) -> Any:
    user = ctx.require_user()
    artifact = db.get_artifact(int(ctx.params["artifact_id"]), int(user["id"]))
    if artifact is None:
        raise HttpError(404, "No such file.")
    try:
        data = artifacts.artifact_bytes(artifact)
    except (PermissionError, FileNotFoundError):
        raise HttpError(404, "That file is no longer available.") from None
    mime = artifacts.KINDS.get(artifact["kind"], ("", "application/octet-stream"))[1]
    return ("file", (artifact["name"], mime, data))


@route("POST", "/api/artifacts/{artifact_id}/save")
def artifact_save(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    artifact = db.get_artifact(int(ctx.params["artifact_id"]), int(user["id"]))
    if artifact is None:
        raise HttpError(404, "No such file.")
    where = str(ctx.body.get("where", "desktop"))

    if where in ("desktop", "drive") and (not ctx.local if where == "desktop" else config.settings.lan):
        raise HttpError(400, "On an agency-server PC, use Download - the file then goes to the "
                             "computer you are sitting at, and nowhere else.")

    if where == "desktop":
        try:
            path = artifacts.save_to_desktop(artifact)
        except OSError as exc:
            raise HttpError(500, f"Could not write to the Desktop: {exc}") from None
        db.mark_artifact_saved(int(artifact["id"]), str(path))
        db.audit("file.save", user_id=int(user["id"]), actor=user["name"], detail=f"desktop: {path}")
        artifacts.reveal(path)
        return {"ok": True, "where": "desktop", "path": str(path),
                "message": f"Saved to {path.parent.name}/{path.name}."}

    if where == "drive":
        if not google.has_drive(int(user["id"])):
            raise HttpError(400, "Connect Google Drive first — Settings → Google.")
        mime = artifacts.KINDS.get(artifact["kind"], ("", "application/octet-stream"))[1]
        try:
            result = google.upload(int(user["id"]), artifact["name"],
                                   artifacts.artifact_bytes(artifact), mime)
        except google.GoogleError as exc:
            raise HttpError(502, str(exc)) from None
        link = result.get("webViewLink", "")
        db.mark_artifact_saved(int(artifact["id"]), link or "drive")
        db.audit("file.save", user_id=int(user["id"]), actor=user["name"], detail="drive")
        return {"ok": True, "where": "drive", "link": link,
                "message": "Saved to your Drive, in the Float folder."}

    raise HttpError(400, "Save where? 'desktop' or 'drive'.")


# ---------------------------------------------------------------------------
# Computer control
# ---------------------------------------------------------------------------
@route("GET", "/api/computer/status")
def computer_status(ctx: Route) -> dict[str, Any]:
    ctx.require_user()
    if not ctx.local:   # never reveal what is happening on the Float computer
        return {"available": False, "why": "Computer control works only on the Float computer."}
    ok, why = computer.available()
    return {"available": ok, "why": why, **computer.current_status()}


@route("POST", "/api/computer/stop")
def computer_stop(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    if not ctx.local:
        raise HttpError(403, "Only someone at the Float computer can stop a computer task.")
    stopped = computer.stop_current()
    if stopped:
        db.audit("computer.stop", user_id=int(user["id"]), actor=user["name"], level="warn")
    return {"stopped": stopped}


# ---------------------------------------------------------------------------
# Model Context Protocol (MCP)
# ---------------------------------------------------------------------------
@route("GET", "/api/mcp")
def mcp_status(ctx: Route) -> dict[str, Any]:
    ctx.require_user()
    return {
        "servers": mcp.list_servers(),
        "tools": mcp.get_tools(),
    }


@route("POST", "/api/mcp/servers", auth="admin")
def mcp_add_server(ctx: Route) -> dict[str, Any]:
    user = ctx.require_admin()
    body = ctx.body
    name = str(body.get("name", "")).strip()
    if not name:
        raise HttpError(400, "Server name is required.")

    command = str(body.get("command", "")).strip()
    args = body.get("args")
    if isinstance(args, str):
        args = shlex.split(args)
    elif not isinstance(args, list):
        args = []

    url = str(body.get("url", "")).strip()
    env = body.get("env") if isinstance(body.get("env"), dict) else {}
    disabled = bool(body.get("disabled", False))

    spec: dict[str, Any] = {"disabled": disabled}
    if command and not ctx.local:
        raise HttpError(403, "Local MCP commands can only be added at the Float computer itself.")
    if command:
        spec["command"] = command
        spec["args"] = args
        if env:
            spec["env"] = env
    elif url:
        spec["url"] = url
        if isinstance(body.get("headers"), dict):
            spec["headers"] = body["headers"]
    else:
        raise HttpError(400, "Either 'command' or 'url' must be specified.")

    try:
        mcp.add_server(name, spec)
    except ValueError as exc:
        raise HttpError(400, str(exc)) from None

    db.audit("mcp.server.add", user_id=int(user["id"]), actor=user["name"],
             detail=f"server: {name}", ip=ctx.ip)
    return {"ok": True, "servers": mcp.list_servers(), "tools": mcp.get_tools()}


@route("DELETE", "/api/mcp/servers/{name}", auth="admin")
def mcp_delete_server(ctx: Route) -> dict[str, Any]:
    user = ctx.require_admin()
    name = str(ctx.params["name"]).strip()
    mcp.remove_server(name)
    db.audit("mcp.server.remove", user_id=int(user["id"]), actor=user["name"],
             detail=f"server: {name}", ip=ctx.ip)
    return {"ok": True, "servers": mcp.list_servers(), "tools": mcp.get_tools()}


@route("POST", "/api/mcp/servers/{name}/toggle", auth="admin")
def mcp_toggle_server(ctx: Route) -> dict[str, Any]:
    user = ctx.require_admin()
    name = str(ctx.params["name"]).strip()
    enabled = bool(ctx.body.get("enabled", True))
    try:
        mcp.toggle_server(name, enabled)
    except KeyError as exc:
        raise HttpError(404, str(exc)) from None
    db.audit("mcp.server.toggle", user_id=int(user["id"]), actor=user["name"],
             detail=f"server: {name} -> {'enabled' if enabled else 'disabled'}", ip=ctx.ip)
    return {"ok": True, "servers": mcp.list_servers(), "tools": mcp.get_tools()}

@route("POST", "/api/mcp/refresh", auth="admin")
def mcp_refresh_tools(ctx: Route) -> dict[str, Any]:
    ctx.require_admin()
    return mcp.refresh()

# ---------------------------------------------------------------------------
# Keys
# ---------------------------------------------------------------------------
@route("POST", "/api/keys")
def keys_put(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    body = ctx.body
    provider = str(body.get("provider", ""))
    secret = str(body.get("key", "")).strip()
    scope = str(body.get("scope", "user"))

    if provider not in config.PROVIDERS:
        raise HttpError(400, "Unknown provider.")
    if scope == "org" and user["role"] != "admin":
        raise HttpError(403, "Only an admin can set the agency's key.")
    if scope == "user" and db.org_get("teacher_own_keys", "1") != "1":
        raise HttpError(403, "Your agency has operators use the agency key. Ask your admin.")
    if not secret:
        raise HttpError(400, "Paste the key.")

    expected = config.PROVIDERS[provider].key_prefix
    if expected and not secret.startswith(expected):
        raise HttpError(400, f"That does not look like a {config.PROVIDERS[provider].label} key — "
                             f"they start with {expected}.")

    ok, detail = providers.verify_key(provider, secret)
    if not ok:
        raise HttpError(400, detail)

    db.put_key(provider, secret, scope, None if scope == "org" else int(user["id"]),
               added_by=int(user["id"]))
    db.audit("key.save", user_id=int(user["id"]), actor=user["name"],
             detail=f"{provider} ({scope})", level="warn")
    return {"ok": True, "detail": detail, "keys": db.key_status(int(user["id"]))}


@route("DELETE", "/api/keys/{provider}")
def keys_drop(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    provider = ctx.params["provider"]
    scope = ctx.query.get("scope", "user")
    if scope == "org" and user["role"] != "admin":
        raise HttpError(403, "Only an admin can remove the agency's key.")
    db.drop_key(provider, scope, int(user["id"]))
    db.audit("key.remove", user_id=int(user["id"]), actor=user["name"],
             detail=f"{provider} ({scope})", level="warn")
    return {"ok": True, "keys": db.key_status(int(user["id"]))}


@route("POST", "/api/unlock", auth="admin")
def unlock(ctx: Route) -> dict[str, Any]:
    """The local transport. Restricted to an admin at the Float host machine."""
    user = ctx.require_admin()
    if not ctx.local:
        raise HttpError(403, "Local runtime settings can only be changed at the Float computer itself.")
    phrase = str(ctx.body.get("phrase", ""))
    allowed, wait = security.unlock_limiter.check(f"unlock:{ctx.ip}")
    if not allowed:
        raise HttpError(429, f"Try again in {int(wait)}s.")
    if not config.rt_phrase_matches(phrase):
        raise HttpError(403, "Not recognised.")
    enable = bool(ctx.body.get("enable", True))
    config.rt_set(enable)
    db.audit("runtime.toggle", user_id=int(user["id"]), actor=user["name"],
             detail="on" if enable else "off", level="warn")
    return {"ok": True, "enabled": config.rt_enabled()}


# ---------------------------------------------------------------------------
# Fleet groups, vehicles, revenue logs, availability, ops tasks, shift schedule
# ---------------------------------------------------------------------------
@route("GET", "/api/classes")
def classes_list(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    return {"classes": db.list_classes(int(user["id"]))}


@route("POST", "/api/classes")
def classes_add(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    body = ctx.body
    name = str(body.get("name", "")).strip()
    if not name:
        raise HttpError(400, "Give the fleet group a name, like 'SUV Fleet'.")
    if len(name) > 80:
        raise HttpError(400, "Class names can be up to 80 characters.")
    class_id = db.add_class(int(user["id"]), name, str(body.get("grade", "")),
                            str(body.get("section", "")), str(body.get("subject", "")),
                            str(body.get("board", user["board"])))
    roster = body.get("roster", body.get("students"))
    added = 0
    if isinstance(roster, str) and roster.strip():
        added = db.add_students(class_id, _parse_roster(roster))
    elif isinstance(roster, list):
        added = db.add_students(class_id, roster)
    return {"ok": True, "id": class_id, "students": added,
            "classes": db.list_classes(int(user["id"]))}


def _parse_roster(text: str) -> list[dict[str, str]]:
    """Accept '1, Aarav Sharma' or 'Aarav Sharma' or '1\tAarav', one per line."""
    entries: list[dict[str, str]] = []
    for line in text.replace("\r", "").split("\n"):
        line = line.strip()
        if not line:
            continue
        parts = [p.strip() for p in re.split(r"[,\t]|\s{2,}", line, maxsplit=1)]
        if len(parts) == 2 and re.fullmatch(r"\d{1,4}", parts[0]) and parts[1]:
            entries.append({"roll": parts[0], "name": parts[1]})
        else:
            match = re.match(r"^(\d{1,4})[.)]\s+(.*)$", line)
            if match and match.group(2).strip():
                entries.append({"roll": match.group(1), "name": match.group(2).strip()})
            else:
                entries.append({"roll": str(len(entries) + 1), "name": line})
    return entries


@route("DELETE", "/api/classes/{class_id}")
def classes_delete(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    if not db.owns_class(int(ctx.params["class_id"]), int(user["id"])):
        raise HttpError(404, "No such class.")
    db.delete_class(int(ctx.params["class_id"]), int(user["id"]))
    return {"ok": True, "classes": db.list_classes(int(user["id"]))}


@route("GET", "/api/classes/{class_id}/students")
def students_list(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    class_id = int(ctx.params["class_id"])
    if not db.owns_class(class_id, int(user["id"])):
        raise HttpError(404, "No such class.")
    return {"students": db.list_students(class_id),
            "marks": db.class_marks(class_id),
            "attendance": db.attendance_range(class_id)}


@route("POST", "/api/classes/{class_id}/students")
def students_add(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    class_id = int(ctx.params["class_id"])
    if not db.owns_class(class_id, int(user["id"])):
        raise HttpError(404, "No such class.")
    roster = ctx.body.get("roster", ctx.body.get("students"))
    entries = _parse_roster(roster) if isinstance(roster, str) else (roster or [])
    added = db.add_students(class_id, entries)
    return {"ok": True, "added": added, "students": db.list_students(class_id)}


@route("POST", "/api/classes/{class_id}/marks")
def marks_add(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    class_id = int(ctx.params["class_id"])
    if not db.owns_class(class_id, int(user["id"])):
        raise HttpError(404, "No such class.")
    valid_ids = {int(x["id"]) for x in db.list_students(class_id)}
    rows = ctx.body.get("marks") or []
    if not isinstance(rows, list):
        raise HttpError(400, "Marks must be a list.")
    clean = []
    for row in rows:
        try:
            if not isinstance(row, dict) or int(row["student_id"]) not in valid_ids:
                raise ValueError
            score = float(row.get("score", 0))
            max_score = float(row.get("max_score", 100))
        except (KeyError, TypeError, ValueError):
            raise HttpError(400, "Each mark needs a student from this class and a numeric score.")
        if not (math.isfinite(score) and math.isfinite(max_score)):
            raise HttpError(400, "Marks must be ordinary numbers.")
        if max_score <= 0:
            raise HttpError(400, "Maximum marks must be more than 0.")
        if not 0 <= score <= max_score:
            raise HttpError(400, f"A score must be between 0 and the maximum ({max_score:g}).")
        clean.append(row)
    count = db.record_marks(clean)
    return {"ok": True, "saved": count}


@route("POST", "/api/classes/{class_id}/attendance")
def attendance_save(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    class_id = int(ctx.params["class_id"])
    if not db.owns_class(class_id, int(user["id"])):
        raise HttpError(404, "No such class.")
    body = ctx.body
    valid_ids = {int(x["id"]) for x in db.list_students(class_id)}
    try:
        present = [int(i) for i in body.get("present") or []]
        absent = [int(i) for i in body.get("absent") or []]
    except (TypeError, ValueError):
        raise HttpError(400, "Attendance lists must contain student ids.")
    if not set(present + absent) <= valid_ids:
        raise HttpError(400, "Attendance includes a student who is not in this class.")
    db.save_attendance(class_id, str(body.get("date", "")), present, absent)
    return {"ok": True}


@route("GET", "/api/tasks")
def tasks_list(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    return {"tasks": db.list_tasks(int(user["id"]), ctx.query.get("all") == "1")}


@route("POST", "/api/tasks")
def tasks_add(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    title = str(ctx.body.get("title", "")).strip()[:240]
    if not title:
        raise HttpError(400, "A task needs a title.")
    db.add_task(int(user["id"]), title, str(ctx.body.get("due", "")))
    return {"ok": True, "tasks": db.list_tasks(int(user["id"]))}


@route("POST", "/api/tasks/{task_id}")
def tasks_update(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    task_id = int(ctx.params["task_id"])
    if not db.owns_task(task_id, int(user["id"])):
        raise HttpError(404, "No such task.")
    db.set_task_done(task_id, int(user["id"]), bool(ctx.body.get("done")))
    return {"ok": True, "tasks": db.list_tasks(int(user["id"]))}


@route("DELETE", "/api/tasks/{task_id}")
def tasks_delete(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    task_id = int(ctx.params["task_id"])
    if not db.owns_task(task_id, int(user["id"])):
        raise HttpError(404, "No such task.")
    db.delete_task(task_id, int(user["id"]))
    return {"ok": True, "tasks": db.list_tasks(int(user["id"]))}


@route("GET", "/api/timetable")
def timetable_get(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    return {"periods": db.list_periods(int(user["id"]))}


@route("POST", "/api/timetable")
def timetable_set(ctx: Route) -> dict[str, Any]:
    user = ctx.require_user()
    raw_periods = ctx.body.get("periods")
    periods = raw_periods if isinstance(raw_periods, list) else []
    db.set_periods(int(user["id"]), periods)
    return {"ok": True, "periods": db.list_periods(int(user["id"])),
            "greeting": greeting.build(db.get_user(int(user["id"])) or user)}


# ---------------------------------------------------------------------------
# Admin
# ---------------------------------------------------------------------------

def _band(calls: int) -> str:
    return "No use" if calls == 0 else "Light" if calls < 20 else "Regular" if calls < 100 else "Frequent"


def _resolve_caps() -> tuple[dict[str, int], int]:
    custom = db.cap_overrides()
    try:
        default_cap = max(0, int(db.org_get("teacher_monthly_paise_cap", "0") or 0))
    except ValueError:
        default_cap = 0
    return custom, default_cap


def _admin_users(rows: list[dict[str, Any]] | None = None,
                 sessions: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Operator rows for the admin screens. By default exact per-person numbers are
    replaced by a usage band, so the panel manages accounts, not individuals' habits."""
    rows = rows if rows is not None else db.usage_summary(30)
    sessions = sessions if sessions is not None else db.active_sessions()
    desk_by_user: dict[int, str] = {}
    for s in sessions:
        uid = int(s["user_id"])
        if uid not in desk_by_user and s.get("ip"):
            desk_by_user[uid] = str(s["ip"])
    exact = db.org_get("usage_detail", "bands") == "exact"
    custom_map, default_cap = _resolve_caps()
    out = []
    for r in rows:
        r = dict(r)
        uid_str = str(r["id"])
        is_custom = uid_str in custom_map
        cap = custom_map[uid_str] if is_custom else default_cap
        r["band"], r["cap_paise"], r["custom_cap"] = _band(r["calls"]), cap, is_custom
        r["desk_ip"] = desk_by_user.get(int(r["id"]), "")
        if not exact:
            for k in ("calls", "tin", "tout", "paise", "latency"):
                r[k] = None
        out.append(r)
    return out


def _fairness(rows: list[dict[str, Any]]) -> dict[str, Any]:
    live = [r for r in rows if r["active"]]
    n = len(live)
    spend = sorted((r["paise"] for r in live), reverse=True)
    total = sum(spend)
    top = max(1, round(n * 0.2)) if n else 0
    custom_map, default_cap = _resolve_caps()
    near = 0
    for r in live:
        uid_str = str(r["id"])
        cap = custom_map[uid_str] if uid_str in custom_map else default_cap
        if cap > 0 and db.month_paise(int(r["id"])) >= 0.8 * cap:
            near += 1
    try:
        budget = int(db.org_get("monthly_paise_budget", "0") or 0)
    except ValueError:
        budget = 0
    return {"accounts": n, "not_started": len([r for r in live if r["calls"] == 0]),
            "top_fifth_share": round(sum(spend[:top]) / total * 100) if total else 0,
            "near_cap": near, "pool_budget": budget, "pool_spent": round(db.pool_paise())}


def _lan_url(port: int) -> str:
    """The address operators on other PCs type when agency-server mode is on."""
    if not config.settings.lan:
        return ""
    scheme = "https" if config.tls_files() else "http"
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("10.255.255.255", 1))
            host = probe.getsockname()[0]
    except OSError:
        host = socket.gethostname()
    return f"{scheme}://{host}:{port}"


@route("GET", "/api/admin/overview", auth="admin")
def admin_overview(ctx: Route) -> dict[str, Any]:
    ctx.require_admin()
    rows = db.usage_summary(30)
    sessions = db.active_sessions()
    total_paise = sum(r["paise"] for r in rows)
    return {
        "org": db.org_all(),
        "lan_url": _lan_url(ctx.request.server.server_port),
        "users": _admin_users(rows, sessions),
        "fairness": _fairness(rows),
        "sessions": sessions,
        "by_day": db.usage_by_day(14),
        "totals": {
            "teachers": len(rows),
            "active": len([r for r in rows if r["active"]]),
            "signed_in": len(sessions),
            "calls": sum(r["calls"] for r in rows),
            "tokens": sum(r["tin"] + r["tout"] for r in rows),
            "rupees": round(total_paise / 100, 2),
        },
        "providers": [
            {"id": p, "label": config.PROVIDERS[p].label,
             "key": bool(db.get_key(p)), "allowed": p in db.allowed_providers()}
            for p in config.PROVIDER_ORDER
        ],
        "notices": db.active_notices(),
        "backup": maintenance.last_backup(),
        "key_health": db.key_health_status(),
        "branches": rental_ops.list_branches(),
        "roles": list(rental_ops.ROLES),
        "prices": providers.price_status(),
    }


@route("POST", "/api/admin/backup", auth="admin")
def admin_backup(ctx: Route) -> dict[str, Any]:
    admin = ctx.require_admin()
    tag = str(ctx.body.get("tag", "")).strip() if ctx.body else ""
    try:
        path = maintenance.backup_now(tag)
    except Exception as exc:  # noqa: BLE001
        maintenance.log_error(f"Manual backup failed: {exc!r}")
        raise HttpError(500, "The backup did not work. Check there is free disk space, "
                             "then try again. Details are in data/float_errors.log.") from None
    db.audit("admin.backup", user_id=int(admin["id"]), actor=admin["name"], detail=path.name, ip=ctx.ip)
    return {"ok": True, "backup": maintenance.last_backup()}


@route("GET", "/api/admin/backups", auth="admin")
def admin_backups_list(ctx: Route) -> dict[str, Any]:
    ctx.require_admin()
    info = maintenance.backup_list_info()
    return {"files": info, "backups": info, "backup": maintenance.last_backup()}


@route("GET", "/api/admin/backups/{filename}/download", auth="admin")
def admin_backup_download(ctx: Route) -> Any:
    admin = ctx.require_admin()
    filename = os.path.basename(str(ctx.params.get("filename", "")))
    if not filename.endswith(".sqlite3") or not filename.startswith("float-"):
        raise HttpError(400, "Invalid backup filename.")
    target = (maintenance.backup_dir() / filename).resolve()
    if not target.is_relative_to(maintenance.backup_dir().resolve()) or not target.is_file():
        raise HttpError(404, "Backup file not found.")
    db.audit("admin.backup.download", user_id=int(admin["id"]), actor=admin["name"], detail=filename, ip=ctx.ip, level="warn")
    return ("file", (filename, "application/x-sqlite3", target.read_bytes()))


@route("POST", "/api/admin/restore", auth="admin")
def admin_restore(ctx: Route) -> dict[str, Any]:
    admin = ctx.require_perm("backup.restore")
    filename = os.path.basename(str(ctx.body.get("filename", "")).strip())
    if not filename.endswith(".sqlite3") or not filename.startswith("float-"):
        raise HttpError(400, "Choose a valid backup file from the list.")
    target = (maintenance.backup_dir() / filename).resolve()
    if not target.is_relative_to(maintenance.backup_dir().resolve()) or not target.is_file():
        raise HttpError(404, "Backup file not found.")
    try:
        kept = maintenance.restore(target)
    except Exception as exc:  # noqa: BLE001
        maintenance.log_error(f"Restore failed: {exc!r}")
        raise HttpError(400, f"Restore could not complete: {exc}") from None
    rental_ops.log_sensitive_action(
        user=admin, action="admin.restore", entity_type="database", entity_id=filename,
        old_val={"previous_copy": kept.name}, new_val={"restored_from": filename},
        reason=str(ctx.body.get("reason", "UI restore")), ip=ctx.ip,
    )
    return {"ok": True, "restored": filename, "safety_copy": kept.name, "backup": maintenance.last_backup()}


@route("POST", "/api/admin/prices", auth="admin")
def admin_prices(ctx: Route) -> dict[str, Any]:
    admin = ctx.require_admin()
    body = ctx.body
    if body.get("checked"):
        providers.mark_prices_checked()
        db.audit("admin.prices", user_id=int(admin["id"]), actor=admin["name"],
                 detail="marked as checked", level="warn", ip=ctx.ip)
        return {"ok": True, "prices": providers.price_status()}
    try:
        providers.set_price_override(str(body.get("provider", "")), str(body.get("model", "")),
                                     body.get("cost_in"), body.get("cost_out"))
    except ValueError as exc:
        raise HttpError(400, str(exc)) from None
    db.audit("admin.prices", user_id=int(admin["id"]), actor=admin["name"],
             detail=f"{body.get('provider')}/{body.get('model')}", level="warn", ip=ctx.ip)
    return {"ok": True, "prices": providers.price_status()}


@route("POST", "/api/admin/users", auth="admin")
def admin_add_user(ctx: Route) -> dict[str, Any]:
    admin = ctx.require_admin()
    body = ctx.body
    email = str(body.get("email", "")).strip().lower()
    name = str(body.get("name", "")).strip()
    password = str(body.get("password", "")) or security.new_token(9)
    raw_role = str(body.get("ops_role") or body.get("role") or "teacher").strip().lower()
    branch_id = max(1, int(body.get("branch_id") or 1))
    role_map = {
        "owner": ("admin", "owner"),
        "admin": ("admin", "owner"),
        "manager": ("admin", "manager"),
        "desk_agent": ("teacher", "desk_agent"),
        "operator": ("teacher", "desk_agent"),
        "teacher": ("teacher", "desk_agent"),
        "accountant": ("teacher", "accountant"),
        "read_only": ("teacher", "read_only"),
    }
    if "@" not in email:
        raise HttpError(400, "That email address does not look right.")
    if raw_role not in role_map:
        raise HttpError(400, "Role must be 'owner', 'manager', 'desk_agent', 'accountant', or 'read_only'.")
    role, ops_role = role_map[raw_role]
    if body.get("password"):
        problems = security.password_problems(password)
        if problems:
            raise HttpError(400, " ".join(problems))
    if db.get_user_by_email(email):
        raise HttpError(409, "There is already an account with that email.")
    school = str(body.get("school", "")).strip() or db.org_get("school_name")
    created = db.create_user(email, name, password, role=role,
                             must_change=True, school=school, ops_role=ops_role, branch_id=branch_id)
    rental_ops.log_sensitive_action(
        user=admin, action="admin.user.add", entity_type="user", entity_id=created["id"],
        old_val=None, new_val={"email": email, "role": role, "ops_role": ops_role, "branch_id": branch_id},
        reason="Added operator account", ip=ctx.ip,
    )
    return {"ok": True, "temp_password": password, "users": _admin_users()}


@route("POST", "/api/admin/users/{user_id}", auth="admin")
def admin_update_user(ctx: Route) -> dict[str, Any]:
    admin = ctx.require_admin()
    user_id = int(ctx.params["user_id"])
    target = db.get_user(user_id)
    if target is None:
        raise HttpError(404, "No such operator.")
    body = ctx.body
    action = str(body.get("action", ""))

    if action == "deactivate":
        if user_id == int(admin["id"]):
            raise HttpError(400, "You cannot switch off your own account.")
        db.update_user(user_id, active=0)
        db.end_all_sessions(user_id)
        detail = "deactivated"
    elif action == "activate":
        db.update_user(user_id, active=1)
        detail = "activated"
    elif action == "set_cap":
        reason = str(body.get("reason", "")).strip()
        raw = body.get("paise")
        if raw in (None, ""):
            db.set_cap_override(user_id, None)
            detail = "limit back to the agency default"
        else:
            if not reason:
                raise HttpError(400, "Add a short reason. Every limit exception is recorded so it stays fair.")
            try:
                f_val = float(raw)
                assert math.isfinite(f_val) and f_val >= 0
                paise = int(round(f_val))
            except (TypeError, ValueError, AssertionError):
                raise HttpError(400, "Limit must be a whole number of rupees, or 0 for none.") from None
            db.set_cap_override(user_id, paise)
            detail = f"limit set to {paise} paise: {reason[:200]}"
    elif action == "make_admin":
        db.update_user(user_id, role="admin", ops_role="owner")
        detail = "made admin"
    elif action in ("make_teacher", "make_operator"):
        if _admin_count() <= 1 and target["role"] == "admin":
            raise HttpError(400, "There has to be at least one admin.")
        db.update_user(user_id, role="teacher", ops_role="desk_agent")
        detail = "made operator"
    elif action in ("set_role", "set_ops_role"):
        new_ops_role = str(body.get("ops_role", "")).strip().lower()
        if new_ops_role not in rental_ops.ROLES:
            raise HttpError(400, f"Invalid role '{new_ops_role}'.")
        new_base_role = "admin" if new_ops_role in {"owner", "manager"} else "teacher"
        if new_base_role != "admin" and target["role"] == "admin" and _admin_count() <= 1:
            raise HttpError(400, "There has to be at least one admin/owner.")
        old_role = target.get("ops_role") or target["role"]
        db.update_user(user_id, role=new_base_role, ops_role=new_ops_role)
        rental_ops.log_sensitive_action(
            user=admin, action="admin.user.role", entity_type="user", entity_id=user_id,
            old_val={"ops_role": old_role}, new_val={"ops_role": new_ops_role},
            reason=str(body.get("reason", f"Changed role to {new_ops_role}")), ip=ctx.ip,
        )
        detail = f"role set to {new_ops_role}"
    elif action == "set_branch":
        branch_id = max(1, int(body.get("branch_id") or 1))
        db.update_user(user_id, branch_id=branch_id)
        detail = f"assigned to branch #{branch_id}"
    elif action == "reset_password":
        temporary = security.new_token(9)
        db.set_password(user_id, temporary)
        db.update_user(user_id, must_change=1)
        db.set_pin(user_id, "")
        db.end_all_sessions(user_id)
        db.audit("admin.user.reset", user_id=int(admin["id"]), actor=admin["name"],
                 detail=f"reset {target['email']}", level="warn", ip=ctx.ip)
        return {"ok": True, "temp_password": temporary, "users": _admin_users()}
    elif action == "sign_out":
        ended = db.end_all_sessions(user_id)
        detail = f"signed out of {ended} session(s)"
    elif action == "delete":
        if user_id == int(admin["id"]):
            raise HttpError(400, "You cannot delete your own account.")
        if target["role"] == "admin" and _admin_count() <= 1:
            raise HttpError(400, "There has to be at least one admin.")
        rental_ops.log_sensitive_action(
            user=admin, action="admin.user.delete", entity_type="user", entity_id=user_id,
            old_val={"email": target["email"], "name": target["name"], "role": target["role"]},
            new_val=None, reason="Deleted operator account", ip=ctx.ip,
        )
        db.delete_user(user_id)
        detail = "deleted, with all their data"
    else:
        raise HttpError(400, "Unknown action.")

    db.audit("admin.user", user_id=int(admin["id"]), actor=admin["name"],
             detail=f"{target['email']}: {detail}", level="warn", ip=ctx.ip)
    return {"ok": True, "detail": detail, "users": _admin_users()}


def _admin_count() -> int:
    return len([u for u in db.list_users() if u["role"] == "admin" and u["active"]])


@route("POST", "/api/admin/org", auth="admin")
def admin_org(ctx: Route) -> dict[str, Any]:
    admin = ctx.require_admin()
    body = ctx.body
    changed: list[str] = []
    for key in ("school_name", "computer_control", "teacher_own_keys", "self_signup",
                "monthly_paise_budget", "require_pin", "teacher_monthly_paise_cap", "usage_detail"):
        if key in body:
            value = str(body[key]).strip()
            if key in ("monthly_paise_budget", "teacher_monthly_paise_cap") and not value.isdigit():
                raise HttpError(400, "Limits must be a whole number of rupees, or 0 for no limit.")
            if key == "usage_detail" and value not in ("bands", "exact"):
                raise HttpError(400, "Usage detail must be 'bands' or 'exact'.")
            db.org_set(key, value)
            changed.append(key)
    if "allowed_providers" in body and isinstance(body["allowed_providers"], list):
        db.org_set("allowed_providers", json.dumps(
            [p for p in body["allowed_providers"] if p in config.PROVIDERS]))
        changed.append("allowed_providers")
    if "computer_control" in body:
        config.settings.computer_control = str(body["computer_control"]) == "1"
    db.audit("admin.org", user_id=int(admin["id"]), actor=admin["name"],
             detail=", ".join(changed), level="warn", ip=ctx.ip)
    return {"ok": True, "org": db.org_all()}


@route("GET", "/api/admin/audit", auth="admin")
def admin_audit(ctx: Route) -> dict[str, Any]:
    ctx.require_admin()
    try:
        lim = max(1, min(500, int(ctx.query.get("limit", "200"))))
    except ValueError:
        lim = 200
    return {"entries": db.audit_tail(
        limit=lim,
        level=ctx.query.get("level", ""),
        user_id=int(ctx.query["user_id"]) if str(ctx.query.get("user_id", "")).isdigit() else None,
    )}


@route("POST", "/api/admin/notice", auth="admin")
def admin_notice(ctx: Route) -> dict[str, Any]:
    admin = ctx.require_admin()
    body = ctx.body
    if body.get("retire"):
        try:
            db.retire_notice(int(body["retire"]))
        except (TypeError, ValueError):
            raise HttpError(400, "Which notice? Send its number.") from None
    else:
        title = str(body.get("title", "")).strip()[:200]
        if not title:
            raise HttpError(400, "A notice needs a title.")
        db.add_notice(title, str(body.get("body", "")), str(body.get("level", "info")),
                      int(admin["id"]))
    db.audit("admin.notice", user_id=int(admin["id"]), actor=admin["name"], ip=ctx.ip)
    return {"ok": True, "notices": db.active_notices()}


@route("GET", "/api/admin/export", auth="admin")
def admin_export(ctx: Route) -> Any:
    admin = ctx.require_admin()
    dash = lambda v: "" if v is None else v  # noqa: E731
    rows: list[list[Any]] = [
        ["Operator", "Role", "Active", "Usage band", "Requests", "Tokens in", "Tokens out", "Estimated ₹"]
    ]
    for e in _admin_users():
        rows.append([e["name"], e["role"], "Yes" if e["active"] else "No", e["band"],
                     dash(e["calls"]), dash(e["tin"]), dash(e["tout"]),
                     "" if e["paise"] is None else round(e["paise"] / 100, 2)])
    db.audit("admin.export", user_id=int(admin["id"]), actor=admin["name"],
             detail="usage report downloaded", level="warn", ip=ctx.ip)
    return ("file", ("float-usage.xlsx", artifacts.KINDS["xlsx"][1], artifacts.build_xlsx(rows)))


# ---------------------------------------------------------------------------
# Enterprise Car Rental Operations Hub (/api/ops/*)
# ---------------------------------------------------------------------------
def _ops_call(fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    try:
        return fn(*args, **kwargs)
    except PermissionError as exc:
        raise HttpError(403, str(exc)) from None
    except (rental_ops.RentalOpsError, ValueError) as exc:
        raise HttpError(400, str(exc)) from None


@route("GET", "/api/ops/summary")
def ops_summary(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("fleet.read")
    branch_q = ctx.query.get("branch_id", "").strip()
    branch_id = int(branch_q) if branch_q.isdigit() else None
    return {
        "branches": rental_ops.list_branches(),
        "vehicles": rental_ops.list_vehicles(branch_id=branch_id),
        "alerts": rental_ops.get_compliance_alerts(30),
        "bookings": rental_ops.list_bookings(branch_id=branch_id),
        "customers": rental_ops.list_customers(),
        "drivers": rental_ops.list_drivers(branch_id=branch_id),
        "invoices": rental_ops.list_invoices(),
        "credit_notes": rental_ops.list_credit_notes(),
        "maintenance": rental_ops.list_maintenance_jobs(),
        "damage": rental_ops.list_damage_records(),
        "dashboard": rental_ops.get_fleet_dashboard(days=30, branch_id=branch_id),
        "collections": rental_ops.get_daily_collection_report(),
    }


@route("GET", "/api/ops/branches")
def ops_branches_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("fleet.read")
    return {"branches": rental_ops.list_branches()}


@route("POST", "/api/ops/branches")
def ops_branches_create(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("branch.write")
    branch = _ops_call(rental_ops.create_branch, ctx.body, user, ctx.ip)
    return {"ok": True, "branch": branch, "branches": rental_ops.list_branches()}


@route("GET", "/api/ops/vehicles")
def ops_vehicles_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("fleet.read")
    branch_q = ctx.query.get("branch_id", "").strip()
    branch_id = int(branch_q) if branch_q.isdigit() else None
    status = ctx.query.get("status", "").strip()
    category = ctx.query.get("category", "").strip()
    return {"vehicles": rental_ops.list_vehicles(branch_id=branch_id, status=status, category=category)}


@route("POST", "/api/ops/vehicles")
def ops_vehicles_create(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("fleet.write")
    veh = _ops_call(rental_ops.create_vehicle, ctx.body, user, ctx.ip)
    return {"ok": True, "vehicle": veh, "vehicles": rental_ops.list_vehicles()}


@route("POST", "/api/ops/vehicles/{vehicle_id}")
def ops_vehicles_update(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("fleet.write")
    vid = int(ctx.params["vehicle_id"])
    veh = _ops_call(rental_ops.update_vehicle, vid, ctx.body, user, ctx.ip)
    return {"ok": True, "vehicle": veh, "vehicles": rental_ops.list_vehicles()}


@route("POST", "/api/ops/vehicles/{vehicle_id}/transfer")
def ops_vehicles_transfer(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("branch.transfer")
    vid = int(ctx.params["vehicle_id"])
    to_branch = int(ctx.body.get("to_branch_id") or 0)
    odometer = float(ctx.body.get("odometer_km") or 0)
    reason = str(ctx.body.get("reason") or "")
    veh = _ops_call(rental_ops.transfer_vehicle, vid, to_branch, odometer, reason, user, ctx.ip)
    return {"ok": True, "vehicle": veh, "vehicles": rental_ops.list_vehicles()}


@route("GET", "/api/ops/vehicles/{vehicle_id}/compliance")
def ops_vehicle_compliance_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("fleet.read")
    vid = int(ctx.params["vehicle_id"])
    return {"compliance": rental_ops.list_vehicle_compliance(vid)}


@route("POST", "/api/ops/vehicles/{vehicle_id}/compliance")
def ops_vehicle_compliance_add(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("compliance.write")
    vid = int(ctx.params["vehicle_id"])
    payload = dict(ctx.body)
    payload["vehicle_id"] = vid
    rec = _ops_call(rental_ops.add_vehicle_compliance, payload, user, ctx.ip)
    return {"ok": True, "record": rec, "compliance": rental_ops.list_vehicle_compliance(vid)}


@route("GET", "/api/ops/alerts")
def ops_alerts(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("fleet.read")
    days_q = ctx.query.get("days", "30").strip()
    days = int(days_q) if days_q.isdigit() else 30
    return rental_ops.get_compliance_alerts(days)


@route("GET", "/api/ops/customers")
def ops_customers_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("customer.read")
    return {"customers": rental_ops.list_customers(include_erased=ctx.query.get("erased") == "1")}


@route("POST", "/api/ops/customers")
def ops_customers_create(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("customer.write")
    cust = _ops_call(rental_ops.create_customer, ctx.body, user, ctx.ip)
    return {"ok": True, "customer": cust, "customers": rental_ops.list_customers()}


@route("GET", "/api/ops/customers/{customer_id}")
def ops_customers_get(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("customer.read")
    cid = int(ctx.params["customer_id"])
    cust = rental_ops.get_customer(cid, user=user, ip=ctx.ip)
    if not cust:
        raise HttpError(404, "Customer not found.")
    return {"customer": cust}


@route("GET", "/api/ops/customers/{customer_id}/export")
def ops_customers_export(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("customer.export")
    cid = int(ctx.params["customer_id"])
    return _ops_call(rental_ops.export_customer_data_dpdp, cid, user, ctx.ip)


@route("POST", "/api/ops/customers/{customer_id}/erase")
def ops_customers_erase(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("customer.erase")
    cid = int(ctx.params["customer_id"])
    reason = str(ctx.body.get("reason") or "")
    res = _ops_call(rental_ops.erase_customer_pii_dpdp, cid, reason, user, ctx.ip)
    return {**res, "customers": rental_ops.list_customers()}


@route("GET", "/api/ops/drivers")
def ops_drivers_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("fleet.read")
    branch_q = ctx.query.get("branch_id", "").strip()
    branch_id = int(branch_q) if branch_q.isdigit() else None
    return {"drivers": rental_ops.list_drivers(branch_id=branch_id)}


@route("POST", "/api/ops/drivers")
def ops_drivers_create(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("fleet.write")
    drv = _ops_call(rental_ops.create_driver, ctx.body, user, ctx.ip)
    return {"ok": True, "driver": drv, "drivers": rental_ops.list_drivers()}


@route("GET", "/api/ops/availability")
def ops_availability(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("booking.read")
    pickup = ctx.query.get("pickup_at", "").strip()
    ret = (ctx.query.get("return_at") or ctx.query.get("expected_return_at") or "").strip()
    cat = ctx.query.get("category", "").strip()
    branch_q = ctx.query.get("branch_id", "").strip()
    branch_id = int(branch_q) if branch_q.isdigit() else None
    vehicles = _ops_call(rental_ops.search_available_vehicles, pickup, ret, category=cat, branch_id=branch_id)
    return {"available": vehicles}


@route("GET", "/api/ops/timeline")
def ops_timeline(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("booking.read")
    branch_q = ctx.query.get("branch_id", "").strip()
    branch_id = int(branch_q) if branch_q.isdigit() else None
    return {"timeline": rental_ops.get_vehicle_timeline(branch_id=branch_id)}


@route("GET", "/api/ops/bookings")
def ops_bookings_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("booking.read")
    status = ctx.query.get("status", "").strip()
    branch_q = ctx.query.get("branch_id", "").strip()
    branch_id = int(branch_q) if branch_q.isdigit() else None
    vid_q = ctx.query.get("vehicle_id", "").strip()
    vid = int(vid_q) if vid_q.isdigit() else None
    return {"bookings": rental_ops.list_bookings(status=status, branch_id=branch_id, vehicle_id=vid)}


@route("POST", "/api/ops/bookings")
def ops_bookings_create(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("booking.write")
    booking = _ops_call(rental_ops.create_booking, ctx.body, user, ctx.ip)
    return {"ok": True, "booking": booking, "bookings": rental_ops.list_bookings()}


@route("POST", "/api/ops/bookings/{booking_id}/status")
def ops_bookings_status(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("booking.write")
    bid = int(ctx.params["booking_id"])
    new_status = str(ctx.body.get("status") or "").strip()
    res = _ops_call(rental_ops.transition_booking, bid, new_status, ctx.body, user, ctx.ip)
    return {"ok": True, **res, "bookings": rental_ops.list_bookings()}


@route("GET", "/api/ops/bookings/{booking_id}/settlement")
def ops_bookings_settlement(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("payment.read")
    bid = int(ctx.params["booking_id"])
    return _ops_call(rental_ops.get_booking_settlement, bid)


@route("POST", "/api/ops/quote")
def ops_quote(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("booking.read")
    return {"quote": _ops_call(rental_ops.calculate_tariff_exact, ctx.body)}


@route("GET", "/api/ops/payments")
def ops_payments_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("payment.read")
    bid_q = ctx.query.get("booking_id", "").strip()
    bid = int(bid_q) if bid_q.isdigit() else None
    return {"payments": rental_ops.list_payments(booking_id=bid)}


@route("POST", "/api/ops/payments")
def ops_payments_record(ctx: Route) -> dict[str, Any]:
    body = ctx.body
    kind = str(body.get("kind") or "advance").strip().lower()
    perm = "payment.refund" if kind in {"refund", "deposit_refund", "cancellation_refund"} else "payment.write"
    user = ctx.require_perm(perm)
    rec = _ops_call(rental_ops.record_payment, body, user, ctx.ip)
    return {"ok": True, "payment": rec, "collections": rental_ops.get_daily_collection_report()}


@route("GET", "/api/ops/invoices")
def ops_invoices_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("invoice.read")
    bid_q = ctx.query.get("booking_id", "").strip()
    bid = int(bid_q) if bid_q.isdigit() else None
    return {"invoices": rental_ops.list_invoices(booking_id=bid)}


@route("POST", "/api/ops/invoices")
def ops_invoices_issue(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("invoice.issue")
    bid = int(ctx.body.get("booking_id") or 0)
    inv = _ops_call(rental_ops.issue_gst_invoice, bid, ctx.body, user, ctx.ip)
    return {"ok": True, "invoice": inv, "invoices": rental_ops.list_invoices()}


@route("GET", "/api/ops/credit-notes")
def ops_credit_notes_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("invoice.read")
    inv_q = ctx.query.get("invoice_id", "").strip()
    inv_id = int(inv_q) if inv_q.isdigit() else None
    return {"credit_notes": rental_ops.list_credit_notes(invoice_id=inv_id)}


@route("POST", "/api/ops/credit-notes")
def ops_credit_notes_issue(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("credit_note.issue")
    inv_id = int(ctx.body.get("invoice_id") or 0)
    cn = _ops_call(rental_ops.issue_credit_note, inv_id, ctx.body, user, ctx.ip)
    return {"ok": True, "credit_note": cn, "credit_notes": rental_ops.list_credit_notes()}


@route("GET", "/api/ops/collections")
def ops_collections(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("payment.read")
    on_date = ctx.query.get("date", "").strip()
    branch_q = ctx.query.get("branch_id", "").strip()
    branch_id = int(branch_q) if branch_q.isdigit() else None
    return rental_ops.get_daily_collection_report(on_date=on_date, branch_id=branch_id)


@route("POST", "/api/ops/reconcile")
def ops_reconcile(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("shift.reconcile")
    rec = _ops_call(rental_ops.reconcile_shift, ctx.body, user, ctx.ip)
    return {"ok": True, "reconciliation": rec}


@route("GET", "/api/ops/maintenance")
def ops_maintenance_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("maintenance.read")
    vid_q = ctx.query.get("vehicle_id", "").strip()
    vid = int(vid_q) if vid_q.isdigit() else None
    status = ctx.query.get("status", "").strip()
    return {"jobs": rental_ops.list_maintenance_jobs(vehicle_id=vid, status=status)}


@route("POST", "/api/ops/maintenance")
def ops_maintenance_create(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("maintenance.write")
    job = _ops_call(rental_ops.create_maintenance_job, ctx.body, user, ctx.ip)
    return {"ok": True, "job": job, "jobs": rental_ops.list_maintenance_jobs()}


@route("POST", "/api/ops/maintenance/{job_id}")
def ops_maintenance_update(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("maintenance.write")
    jid = int(ctx.params["job_id"])
    job = _ops_call(rental_ops.update_maintenance_job, jid, ctx.body, user, ctx.ip)
    return {"ok": True, "job": job, "jobs": rental_ops.list_maintenance_jobs()}


@route("GET", "/api/ops/damage")
def ops_damage_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("damage.read")
    vid_q = ctx.query.get("vehicle_id", "").strip()
    vid = int(vid_q) if vid_q.isdigit() else None
    return {"damage": rental_ops.list_damage_records(vehicle_id=vid)}


@route("POST", "/api/ops/damage")
def ops_damage_add(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("damage.write")
    rec = _ops_call(rental_ops.add_damage_record, ctx.body, user, ctx.ip)
    return {"ok": True, "record": rec, "damage": rental_ops.list_damage_records()}


@route("GET", "/api/ops/signatures")
def ops_signatures_list(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("booking.read")
    bid_q = ctx.query.get("booking_id", "").strip()
    bid = int(bid_q) if bid_q.isdigit() else None
    return {"signatures": rental_ops.list_signatures(booking_id=bid)}


@route("POST", "/api/ops/signatures")
def ops_signatures_capture(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("signature.write")
    sig = _ops_call(rental_ops.capture_signature, ctx.body, user, ctx.ip)
    return {"ok": True, "signature": sig}


@route("GET", "/api/ops/dashboard")
def ops_dashboard(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("dashboard.read")
    days_q = ctx.query.get("days", "30").strip()
    days = int(days_q) if days_q.isdigit() else 30
    branch_q = ctx.query.get("branch_id", "").strip()
    branch_id = int(branch_q) if branch_q.isdigit() else None
    return rental_ops.get_fleet_dashboard(days=days, branch_id=branch_id)


@route("POST", "/api/ops/import/preview")
def ops_import_preview(ctx: Route) -> dict[str, Any]:
    ctx.require_perm("import.write")
    target = str(ctx.body.get("target") or "vehicles")
    filename = str(ctx.body.get("filename") or "import.csv")
    content = str(ctx.body.get("content") or "")
    return _ops_call(rental_ops.preview_bulk_import, target, filename, content)


@route("POST", "/api/ops/import/commit")
def ops_import_commit(ctx: Route) -> dict[str, Any]:
    user = ctx.require_perm("import.write")
    target = str(ctx.body.get("target") or "vehicles")
    rows = ctx.body.get("valid_rows") or []
    if not isinstance(rows, list):
        raise HttpError(400, "valid_rows must be a list.")
    return _ops_call(rental_ops.commit_bulk_import, target, rows, user, ctx.ip)


@route("POST", "/api/system/shutdown", auth="none")
def system_shutdown(ctx: Route) -> dict[str, Any]:
    """Gracefully shut down the Float server."""
    if "application/json" not in (ctx.request.headers.get("Content-Type") or "").lower():
        raise HttpError(415, "Send this request as JSON.")
    is_admin = ctx.user and ctx.user.get("role") == "admin"
    if not (ctx.local or is_admin):
        raise HttpError(403, "Only someone at the Float computer or an agency admin can shut down the server.")

    user_id = int(ctx.user["id"]) if ctx.user else None
    actor = ctx.user["name"] if ctx.user else ("localhost" if ctx.local else "system")
    db.audit("server.shutdown", user_id=user_id, actor=actor, ip=ctx.ip, level="warn")

    try:
        mcp.shutdown()
    except Exception:
        pass

    try:
        computer.stop_current()
    except Exception:
        pass

    try:
        pid_file = config.pid_path()
        if pid_file.exists():
            pid_file.unlink(missing_ok=True)
    except Exception:
        pass

    srv = ctx.request.server

    def _do_shutdown() -> None:
        time.sleep(0.4)
        try:
            srv.shutdown()
        except Exception:
            pass
        try:
            srv.server_close()
        except Exception:
            pass
        time.sleep(0.2)
        os._exit(0)

    threading.Thread(target=_do_shutdown, daemon=True, name="float-shutdown").start()
    return {"ok": True, "message": "Float server is shutting down."}


# ---------------------------------------------------------------------------
# The HTTP layer
# ---------------------------------------------------------------------------
class FloatHandler(BaseHTTPRequestHandler):
    server_version = f"Float/{config.VERSION}"
    protocol_version = "HTTP/1.1"
    timeout = 30   # seconds a client may stall on a read before its thread is freed

    # -- plumbing ----------------------------------------------------------
    def setup(self) -> None:
        super().setup()
        try:   # send each streamed chunk immediately instead of waiting to batch it
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        if isinstance(self.connection, ssl.SSLSocket):
            # Perform the TLS handshake on the worker thread (with a timeout) rather
            # than inside accept(), so one stalled socket cannot freeze the server.
            self.connection.settimeout(min(self.timeout or 10, 10))
            self.connection.do_handshake()
            if self.timeout is not None:
                self.connection.settimeout(self.timeout)

    def log_message(self, fmt: str, *args: Any) -> None:
        return  # the audit log is the log

    def json_body(self) -> dict[str, Any]:
        if getattr(self, "_body_cache", None) is not None:
            return self._body_cache
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            self.close_connection = True
            raise HttpError(400, "Bad Content-Length header.") from None
        if length <= 0:
            self._body_cache = {}
        elif length > config.settings.max_upload_bytes:
            self.close_connection = True   # the unread body would corrupt the next request
            raise HttpError(413, "That is larger than Float accepts.")
        else:
            raw = self.rfile.read(length)
            try:
                parsed = json.loads(raw.decode("utf-8"))
                parsed = parsed if isinstance(parsed, dict) else {"value": parsed}
                if set(parsed) == {"enc"}:      # sealed: AES-256-GCM envelope
                    try:
                        parsed, self._enc_key = transport.open_request(
                            parsed["enc"], urllib.parse.urlparse(self.path).path)
                    except transport.TransportError as exc:
                        if exc.rekey:
                            raise HttpError(409, str(exc), rekey=True) from None
                        raise HttpError(400, str(exc)) from None
                self._body_cache = parsed
            except ValueError:
                raise HttpError(400, "The request body was not valid JSON.") from None
        return self._body_cache

    @property
    def query(self) -> dict[str, str]:
        parsed = urllib.parse.urlparse(self.path)
        return {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query, keep_blank_values=True).items() if v}

    def _host_ok(self) -> bool:
        raw_host = (self.headers.get("Host") or "").strip()
        if raw_host.startswith("["):
            host = raw_host.split("]")[0] + "]" if "]" in raw_host else raw_host
        else:
            host = raw_host.split(":")[0]
        if host.lower() in {"127.0.0.1", "localhost", "[::1]", "::1", config.settings.host.lower()}:
            return True
        if not config.settings.lan:
            return False
        allowed = {h.strip().lower() for h in config.settings.allowed_hosts.split(",") if h.strip()}
        allowed.update({_LOCAL_HOSTNAME, f"{_LOCAL_HOSTNAME}.local"})
        if host.lower() in allowed:
            return True
        try:   # a bare IP address cannot be a DNS-rebinding name
            ipaddress.ip_address(host.strip("[]"))
            return True
        except ValueError:
            return False

    # -- verbs -------------------------------------------------------------
    def do_GET(self) -> None:
        self._dispatch("GET")

    def do_POST(self) -> None:
        self._dispatch("POST")

    def do_DELETE(self) -> None:
        self._dispatch("DELETE")

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Allow", "GET, POST, DELETE, OPTIONS")
        self.send_header("Content-Length", "0")
        self.end_headers()

    # -- dispatch ----------------------------------------------------------
    def _dispatch(self, method: str) -> None:
        self._body_cache = None
        self._enc_key = None
        try:
            if not self._host_ok():
                raise HttpError(403, "Refused: unexpected Host header.")

            path = urllib.parse.urlparse(self.path).path
            matched_route: tuple[dict[str, str], Handler, str] | None = None
            exact = _exact_routes.get((method, path))
            if exact is not None and (method, exact[0], exact[1], exact[2]) in _routes:
                matched_route = ({}, exact[1], exact[2])
            else:
                for verb, pattern, handler, auth in _routes:
                    if verb != method:
                        continue
                    match = pattern.match(path)
                    if match:
                        matched_route = (match.groupdict(), handler, auth)
                        break

            if matched_route is not None:
                params, handler, auth = matched_route
                if method == "POST" and _SEALED.match(path):
                    self.json_body()
                    if self._enc_key is None and not transport.plaintext_allowed():
                        raise HttpError(400, "Please reload Float. This page is out of date and "
                                             "would send your password unprotected.")
                ctx = Route(self, params)
                ctx.token = self._bearer()
                if ctx.token:
                    ctx.user = db.resolve_session(ctx.token, ctx.ip)
                if auth != "none" and ctx.user is None:
                    raise HttpError(401, "Sign in to continue.")
                if (auth != "none" and ctx.user is not None and ctx.user["must_change"]
                        and (method, path) not in _MUST_CHANGE_ALLOWED):
                    # A temporary password may only be used to choose a real one.
                    raise HttpError(403, "Please set your own password first "
                                         "(Settings → Security).", must_change=True)
                if auth == "admin":
                    ctx.require_admin()
                self._send_result(handler(ctx))
                return

            if method == "GET":
                self._serve_static(path)
                return
            raise HttpError(404, "No such endpoint.")

        except HttpError as exc:
            self._send_json({"error": exc.message, **exc.extra}, exc.status)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:  # pragma: no cover
            # The details go to data/float_errors.log; the operator gets a calm
            # message and a reference, not a stack trace or an internal path.
            ref = _log_unexpected()
            try:
                self._send_json({"error": "Something went wrong on Float's side. Your work "
                                          f"is safe. Please try again. (ref {ref})"}, 500)
            except Exception:
                pass

    def _bearer(self) -> str:
        header = (self.headers.get("Authorization") or "").strip()
        if header[:7].lower() == "bearer ":
            return header[7:].strip()
        # Tokens are deliberately NOT read from the URL: they would end up in
        # browser history and logs, and the app never sends them that way.
        return ""

    # -- responses ---------------------------------------------------------
    def _send_result(self, result: Any) -> None:
        if isinstance(result, tuple) and len(result) == 2:
            kind, payload = result
            if kind == "sse":
                self._send_sse(payload)
                return
            if kind == "file":
                name, mime, data = payload
                self._send_bytes(data, mime, filename=name)
                return
            if kind == "html":
                self._send_bytes(payload.encode("utf-8"), "text/html; charset=utf-8")
                return
        self._send_json(result if result is not None else {"ok": True})

    def _headers(self, status: int, mime: str, length: int | None, extra: dict[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", mime)
        if length is not None:
            self.send_header("Content-Length", str(length))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()

    def _send_json(self, payload: Any, status: int = 200) -> None:
        if status == 200 and getattr(self, "_enc_key", None):   # answer a sealed request sealed
            payload = transport.seal_response(self._enc_key, urllib.parse.urlparse(self.path).path, payload)
        data = json.dumps(payload, default=str).encode("utf-8")
        self._headers(status, "application/json; charset=utf-8", len(data))
        self.wfile.write(data)

    def _send_bytes(self, data: bytes, mime: str, filename: str = "") -> None:
        extra = {}
        if filename:
            quoted = urllib.parse.quote(filename)
            extra["Content-Disposition"] = f'attachment; filename="{quoted}"; filename*=UTF-8\'\'{quoted}'
        self._headers(200, mime, len(data), extra)
        self.wfile.write(data)

    def _send_sse(self, stream: Any) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-transform")
        # No Content-Length on a stream: close the connection when it ends so the
        # browser sees end-of-stream instead of waiting forever.
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        self.close_connection = True
        try:
            for event in stream:
                frame = f"data: {json.dumps(event, default=str)}\n\n".encode("utf-8")
                self.wfile.write(frame)
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass   # the operator closed the tab mid-answer; nothing to clean up
        except Exception:  # pragma: no cover
            ref = _log_unexpected()
            try:
                message = f"Float lost the thread of that answer. Please try again. (ref {ref})"
                self.wfile.write(f"data: {json.dumps({'type': 'error', 'message': message})}\n\n".encode())
            except Exception:
                pass

    # -- static ------------------------------------------------------------
    _PAGES = {"/": "index.html", "/login": "login.html", "/admin": "admin.html"}

    def _serve_static(self, path: str) -> None:
        if path == "/float.ico":
            target = Path(config.WEB_ROOT).resolve().parent.parent / "float.ico"
        elif path in self._PAGES:
            target = Path(config.WEB_ROOT) / self._PAGES[path]
        else:
            decoded = urllib.parse.unquote(path)
            if "\x00" in decoded:
                raise HttpError(404, "Not found.")
            clean = posixpath.normpath(decoded).lstrip("/")
            root = Path(config.WEB_ROOT).resolve()
            target = (root / clean).resolve()
            if not target.is_relative_to(root):
                raise HttpError(403, "Refused.")
        if not target.is_file():
            raise HttpError(404, "Not found.")

        st = target.stat()
        mtime_ns, size = st.st_mtime_ns, st.st_size
        with _STATIC_LOCK:
            cached = _STATIC_CACHE.get(target)
            if cached and cached[0] == mtime_ns and cached[1] == size:
                _, _, data, mime, etag = cached
            else:
                mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
                if mime.startswith("text/") or mime in {"application/javascript", "application/json"}:
                    mime += "; charset=utf-8"
                data = target.read_bytes()
                etag = f'"{hashlib.blake2b(data, digest_size=8).hexdigest()}"'
                _STATIC_CACHE[target] = (mtime_ns, size, data, mime, etag)

        if target.suffix != ".html" and self.headers.get("If-None-Match") == etag:
            self.send_response(HTTPStatus.NOT_MODIFIED)
            self.send_header("ETag", etag)
            self.end_headers()
            return

        extra: dict[str, str] = {"ETag": etag}
        if target.suffix == ".html":
            extra["Content-Security-Policy"] = (
                "default-src 'self'; img-src 'self' data: blob: https:; "
                "style-src 'self' 'unsafe-inline'; script-src 'self'; "
                "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"
            )
        self._headers(200, mime, len(data), extra)
        self.wfile.write(data)


class FloatServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 64
    # On Windows SO_REUSEADDR lets a second process steal an already-bound port
    # (for example 0.0.0.0 alongside 127.0.0.1). Keep exclusive port ownership
    # on Windows so "port already in use" is detected reliably.
    allow_reuse_address = sys.platform != "win32"

    def __init__(self, server_address: tuple[str, int], RequestHandlerClass: type[BaseHTTPRequestHandler]) -> None:
        self._pool = concurrent.futures.ThreadPoolExecutor(max_workers=24, thread_name_prefix="float-http")
        super().__init__(server_address, RequestHandlerClass)

    def process_request(self, request: Any, client_address: Any) -> None:
        try:
            self._pool.submit(self.process_request_thread, request, client_address)
        except RuntimeError:
            self.close_request(request)

    def server_close(self) -> None:
        try:
            self._pool.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass
        super().server_close()

    def server_bind(self) -> None:
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            try:
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            except OSError:
                pass
        super().server_bind()

    def handle_error(self, request, client_address) -> None:
        # A browser that gave up, or someone typing http:// at the https port,
        # is not a Float fault - do not spray a traceback for it.
        if isinstance(sys.exc_info()[1], (ssl.SSLError, ConnectionError, TimeoutError)):
            return
        super().handle_error(request, client_address)


def serve(host: str | None = None, port: int | None = None) -> FloatServer:
    config.ensure_dirs()
    db.init()
    db.purge_stale_sessions()
    maintenance.start_daily_backups()      # one now, then at most one a day; never raises
    maintenance.prune_in_background()      # old audit/usage rows, in small batches
    server = FloatServer((host or config.settings.host, config.settings.port if port is None else port), FloatHandler)
    tls = config.tls_files() if port != 0 else None
    if tls:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(*tls)
        server.socket = context.wrap_socket(server.socket, server_side=True,
                                            do_handshake_on_connect=False)
    elif config.settings.lan:
        db.audit("server.insecure", level="warn",
                 detail="Agency-server mode is running without HTTPS: passwords cross the network in plain text.")
    threading.Thread(target=server.serve_forever, daemon=True, name="float-http").start()
    return server
